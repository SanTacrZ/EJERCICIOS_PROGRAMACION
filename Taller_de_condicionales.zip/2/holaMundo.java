public class holaMundo {
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
    }
    
}
